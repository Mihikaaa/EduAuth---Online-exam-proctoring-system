from datetime import datetime
from mongoengine import Document, ReferenceField, StringField, ListField, DateField, IntField
from models.student import Student
from models.exam import Exam

class Violation(Document):
    student = ReferenceField(Student, required=True)
    exam = ReferenceField(Exam, required=True)
    image_url = StringField(required=True)
    head_rotation = StringField(required=False)
    violation_objects = ListField(StringField(required=False))
    person_count = IntField(required=False)
    createdAt = DateField(
    required=True, default=lambda: datetime.utcnow()
)