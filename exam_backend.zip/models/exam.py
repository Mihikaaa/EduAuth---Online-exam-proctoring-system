from datetime import datetime
from mongoengine import Document, StringField, DateField, ListField


class Exam(Document):
    createdAt = DateField(
        required=True, default=lambda: datetime.now()
    )
    questions = ListField(
        fields={
            "question": StringField(required=True),
            "answers": ListField(StringField(required=True)),
            "correctAnswer": StringField(required=True),
        }
    )
