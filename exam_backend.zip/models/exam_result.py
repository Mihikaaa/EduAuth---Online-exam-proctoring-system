from mongoengine import Document, ReferenceField,  ListField,  IntField, DateField
from models.student import Student
from models.exam import Exam
from datetime import datetime


class ExamResult(Document):
    student = ReferenceField(Student, required=True)
    exam = ReferenceField(Exam, required=True)
    user_answers = ListField(IntField(required=True))
    marks = IntField(required=True)
    createdAt = DateField(
    required=True, default=lambda: datetime.utcnow()
)