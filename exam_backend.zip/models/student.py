from mongoengine import Document, StringField, DateField

class Student(Document):
    name = StringField(required=True)
    date_of_birth = DateField(required=True)
    username = StringField(required=True, unique=True)  
    password = StringField(required=True) 
    address = StringField(required=True)
    contact_number = StringField(required=True)