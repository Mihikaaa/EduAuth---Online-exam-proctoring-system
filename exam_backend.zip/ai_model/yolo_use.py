from ultralytics import YOLO

def detect_objects( image_path):
    # Load the YOLOv5 model
    model = YOLO('yolov5su.pt')

    # Perform inference on an image
    results = model(image_path)

    # Access the first result (assuming you are processing only one image)
    result = results[0]

    # Extract and return the names of detected objects
    object_names = [result.names[int(box.cls)] for box in result.boxes]
    return object_names

