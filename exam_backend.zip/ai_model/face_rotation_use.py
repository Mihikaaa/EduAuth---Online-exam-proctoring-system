import cv2
import mediapipe as mp
import os
import math

# Initialize mediapipe face mesh
mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(static_image_mode=True, max_num_faces=1, min_detection_confidence=0.5)
mp_drawing = mp.solutions.drawing_utils

def calculate_angle(p1, p2):
    """Calculate the angle between two points in degrees."""
    return math.degrees(math.atan2(p2[1] - p1[1], p2[0] - p1[0]))

def determine_head_orientation(image_path):
    if not os.path.isfile(image_path):
        return "Error: The file at {} does not exist.".format(image_path)
    else:
        img = cv2.imread(image_path)
        
        if img is None:
            return "Error: Image not loaded."
        else:
            rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

            results = face_mesh.process(rgb_img)

            if results.multi_face_landmarks:
                for landmarks in results.multi_face_landmarks:
                    landmarks = [(lm.x, lm.y) for lm in landmarks.landmark]

                    left_eye = landmarks[33]  # Left eye corner
                    right_eye = landmarks[263]  # Right eye corner
                    nose_tip = landmarks[1]  # Nose tip
                    chin = landmarks[152]  # Chin point

                    eye_line_angle = calculate_angle(left_eye, right_eye)
                    nose_chin_angle = calculate_angle(nose_tip, chin)

                    if abs(left_eye[0] - right_eye[0]) > 0.05:  # Threshold to account for noise
                        if nose_tip[0] < (left_eye[0] + right_eye[0]) / 2:
                            return "Head turned left"
                        else:
                            return "Head turned right"
                    else:
                        if abs(nose_tip[1] - chin[1]) < 0.02:  # Threshold for vertical tilt
                            return "Head facing forward"
                        elif nose_tip[1] < chin[1]:
                            return "Head tilted down"
                        else:
                            return "Head tilted up"
            else:
                return "No face landmarks detected."

