from flask import Blueprint
from controllers.exam_controller import create_exam, get_exam, update_exam, delete_exam, get_all_exams

exam_blueprint = Blueprint('exam_blueprint', __name__)

# Create routes with the blueprint
exam_blueprint.route('/create', methods=['POST'])(create_exam)
exam_blueprint.route('/get/<id>', methods=['GET'])(get_exam)
exam_blueprint.route('/update/<id>', methods=['PUT'])(update_exam)
exam_blueprint.route('/delete/<id>', methods=['DELETE'])(delete_exam)
exam_blueprint.route('/all', methods=['GET'])(get_all_exams)