from flask import Blueprint
from controllers.login_controller import login

login_blueprint = Blueprint('login_blueprint', __name__)

# Create routes with the blueprint
login_blueprint.route('/log-now', methods=['POST'])(login)
