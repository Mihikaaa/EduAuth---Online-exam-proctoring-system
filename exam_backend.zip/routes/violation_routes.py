from flask import Blueprint
from controllers.violation_controller import get_all_violations

violation_blueprint = Blueprint('violation_blueprint', __name__)

# Create routes with the blueprint
violation_blueprint.route('/violations', methods=['GET'])(get_all_violations)