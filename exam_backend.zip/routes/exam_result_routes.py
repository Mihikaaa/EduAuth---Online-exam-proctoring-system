from flask import Blueprint
from controllers.result_controller import create_exam_result,get_all_exam_results,get_exam_result,update_exam_result,delete_exam_result

exam_result_blueprint = Blueprint('exam_result_blueprint', __name__)

# Create routes with the blueprint
exam_result_blueprint.route('/create', methods=['POST'])(create_exam_result)
exam_result_blueprint.route('/all', methods=['GET'])(get_all_exam_results)
exam_result_blueprint.route('/get/<id>', methods=['GET'])(get_exam_result)
exam_result_blueprint.route('/update/<id>', methods=['PUT'])(update_exam_result)
exam_result_blueprint.route('/delete/<id>', methods=['DELETE'])(delete_exam_result)