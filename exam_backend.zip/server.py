from flask import Flask, send_from_directory
from flask_cors import CORS
from flask_mongoengine import MongoEngine
from dotenv import load_dotenv
import os
from routes.student_routes import student_blueprint
from routes.ai_routes import ai_blueprint
from routes.login_routes import login_blueprint
from routes.contact_routes import contact_blueprint
from routes.exam_routes import exam_blueprint
from routes.violation_routes import violation_blueprint
from routes.exam_result_routes import exam_result_blueprint

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)

# Configurations
app.config['MONGODB_SETTINGS'] = {
    'db': os.environ.get('MONGO_DB_NAME'),  # Retrieve database name from .env
    'host': os.environ.get('MONGO_URI')
}

db = MongoEngine(app)
CORS(app)

app.register_blueprint(student_blueprint, url_prefix='/api/students')
app.register_blueprint(ai_blueprint, url_prefix='/api/ai')
app.register_blueprint(login_blueprint, url_prefix='/api/login')
app.register_blueprint(contact_blueprint, url_prefix='/api/contact')
app.register_blueprint(exam_blueprint, url_prefix='/api/exam')
app.register_blueprint(violation_blueprint, url_prefix='/api/violation')
app.register_blueprint(exam_result_blueprint, url_prefix='/api/result')


@app.route('/images/<path:path>')
def send_image(path):
    return send_from_directory('violation', path)

@app.route('/')
def index():
    return "API is running..."

if __name__ == '__main__':
    app.run(port=int(os.environ.get('PORT', 3001)),debug=True)