from flask import jsonify
from models.violation import Violation
from models.student import Student

def get_all_violations():
    """
    Retrieves all violations from the database.

    Returns:
        A JSON response containing a list of all violations.
    """
    violations = Violation.objects.all()
    if violations:
        violations_data = []
        for violation in violations:
            student = Student.objects.get(id=violation.student.id)
            violation_dict = {
                'id': str(violation.id),
                'student': {
                    'id': str(violation.student.id),
                    'name': student.name
                },
                'exam': str(violation.exam.id),
                'image_url': violation.image_url,
                'head_rotation': violation.head_rotation,
                'objects': violation.violation_objects,
                'person_count': violation.person_count,
                'createdAt': violation.createdAt
            }
            violations_data.append(violation_dict)
        return jsonify(violations_data), 200
    else:
        return jsonify({"message": "No violations found"}), 404