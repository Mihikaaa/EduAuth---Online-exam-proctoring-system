from flask import jsonify, request
from models.exam import Exam

def create_exam():
    data = request.json
    exam = Exam(**data)
    exam.save()
    return jsonify({"message": "Exam saved successfully", "id": str(exam.id)}), 200

def get_all_exams():
    exams = Exam.objects.all()
    if exams:
        exams_data = []
        for exam in exams:
            exam_dict = {
                'id': str(exam.id),
                'createdAt': exam.createdAt,
                'questions': exam.questions
            }
            exams_data.append(exam_dict)
        return jsonify(exams_data), 200
    else:
        return jsonify({"message": "No exams found"}), 404

def get_exam(id):
    exam = Exam.objects(id=id).first()
    if exam:
        return jsonify({
            'id': str(exam.id),
            'createdAt': exam.createdAt,
            'questions': exam.questions
        })
    else:
        return jsonify({"error": "Exam not found"}), 404

def update_exam(id):
    data = request.json
    exam = Exam.objects(id=id).first()
    if exam:
        exam.update(**data)
        return jsonify({"message": "Exam updated successfully"}), 200
    else:
        return jsonify({"error": "Exam not found"}), 404

def delete_exam(id):
    exam = Exam.objects(id=id).first()
    if exam:
        exam.delete()
        return jsonify({"message": "Exam deleted successfully"})
    else:
        return jsonify({"error": "Exam not found"}), 404