from flask import jsonify, request
from models.exam_result import ExamResult
from models.student import Student
from models.exam import Exam

def create_exam_result():
    data = request.json
    student = Student.objects(id=data['student_id']).first()
    exam = Exam.objects(id=data['exam_id']).first()
    if student and exam:
        exam_result = ExamResult(student=student, exam=exam, user_answers=data['user_answers'], marks=data['marks'])
        exam_result.save()
        return jsonify({"message": "Exam result saved successfully", "id": str(exam_result.id)}), 200
    else:
        return jsonify({"error": "Student or exam not found"}), 404

def get_all_exam_results():
    exam_results = ExamResult.objects.all()  # Retrieve all exam results from the database
    if exam_results:
        exam_results_data = []
        for exam_result in exam_results:
            exam_result_dict = {
                'id': str(exam_result.id),  # Convert MongoDB ObjectId to string
                'student_name': exam_result.student.name,
                'exam_id': str(exam_result.exam.id),
                'user_answers': exam_result.user_answers,
                'marks': exam_result.marks,
                'created_at': exam_result.createdAt.isoformat() if exam_result.createdAt else None,  # Ensure date is in ISO format
            }
            exam_results_data.append(exam_result_dict)
        return jsonify(exam_results_data), 200
    else:
        return jsonify({"message": "No exam results found"}), 404
    

def get_exam_result(id):
    exam_result = ExamResult.objects(id=id).first()
    if exam_result:
        exam_result_dict = {
            'id': str(exam_result.id),  # Convert MongoDB ObjectId to string
            'student_id': str(exam_result.student.id),
            'exam_id': str(exam_result.exam.id),
            'user_answers': exam_result.user_answers,
            'marks': exam_result.marks,
            'created_at': exam_result.createdAt.isoformat() if exam_result.createdAt else None,  # Ensure date is in ISO format
        }
        return jsonify(exam_result_dict)
    else:
        return jsonify({"error": "Exam result not found"}), 404

def update_exam_result(id):
    data = request.json
    exam_result = ExamResult.objects(id=id).first()
    if exam_result:
        student = Student.objects(id=data['student_id']).first()
        exam = Exam.objects(id=data['exam_id']).first()
        if student and exam:
            exam_result.update(student=student, exam=exam, user_answers=data['user_answers'], marks=data['marks'])
            return jsonify({"message": "Exam result updated successfully"})
        else:
            return jsonify({"error": "Student or exam not found"}), 404
    else:
        return jsonify({"error": "Exam result not found"}), 404

def delete_exam_result(id):
    exam_result = ExamResult.objects(id=id).first()
    if exam_result:
        exam_result.delete()
        return jsonify({"message": "Exam result deleted successfully"})
    else:
        return jsonify({"error": "Exam result not found"}), 404