import os
from flask import jsonify, request
from ai_model.model_train import run
from ai_model.model_train import preprocess_image
from ai_model.face_rotation_use import determine_head_orientation
from ai_model.yolo_use import detect_objects
from ai_model.person_count import detect_faces
from joblib import load
import pickle
import cv2
import numpy as np
from PIL import Image
import uuid
import datetime
from models.exam import Exam
from models.student import Student
from models.violation import Violation

UPLOAD_DATASET_FOLDER = 'ai_model/dataset'
MODEL_PATH = 'ai_model/face_recognition_model.joblib'
ENCODER_PATH = 'ai_model/label_encoder.pickle'
FACE_CASCADE_PATH = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
UPLOAD_FOLDER = 'temp'
VIOLATION_FOLDER = 'violation'

def create_folders():
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)
    if not os.path.exists(VIOLATION_FOLDER):
        os.makedirs(VIOLATION_FOLDER)



def image_upload(student_id):
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files['file']

    if not file or file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    try:
        # Ensure the folder exists or create it
        student_folder = os.path.join(UPLOAD_DATASET_FOLDER, str(student_id))
        os.makedirs(student_folder, exist_ok=True)

        # Check the number of files in the folder
        files = os.listdir(student_folder)
        if len(files) >= 10:
            # If 10 or more files exist, remove them
            for f in files:
                os.remove(os.path.join(student_folder, f))

        # Generate a unique filename using UUID
        unique_filename = f"{uuid.uuid4()}.jpg"  # Generates a unique identifier and appends .jpg

        # Assume the file is an image and save it directly as JPEG
        image = Image.open(file.stream)  # Open the image file
        save_path = os.path.join(student_folder, unique_filename)  # Save with unique filename
        image.save(save_path, format='JPEG')  # Save as JPEG

        return jsonify({"message": "File uploaded successfully", "filename": unique_filename}), 201
    except Exception as e:
        return jsonify({"error": "Could not process the uploaded file: " + str(e)}), 500

def train():
    try:
        run()
        return jsonify({"message": "Model trained successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

def load_model_and_encoder():
    model = None
    encoder = None
    try:
        # Load model
        model = load(MODEL_PATH)
        # Load encoder
        with open(ENCODER_PATH, 'rb') as f:
            encoder = pickle.load(f)
    except Exception as e:
        print(f"Error loading model or encoder: {e}")
    return model, encoder

def predict():
    try:
        # Load model and encoder
        model, encoder = load_model_and_encoder()

        if not model or not encoder:
            return jsonify({"error": "Model or encoder not found"}), 500

        # Load image from request
        file = request.files['file']
        img = cv2.imdecode(np.frombuffer(file.read(), np.uint8), cv2.IMREAD_COLOR)

        # Detect faces in the image
        face_cascade = cv2.CascadeClassifier(FACE_CASCADE_PATH)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

        # Make predictions for each detected face
        persons = []
        for (x, y, w, h) in faces:
            face_img = img[y:y+h, x:x+w]
            processed_img = preprocess_image(face_img)
            prediction = model.predict(processed_img.flatten().reshape(1, -1))
            person = encoder.inverse_transform(prediction)[0]
            persons.append(person)

        return jsonify({"persons": persons}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
def analyze_image():
    create_folders()
    student_id = request.form.get('student_id')
    exam_id = request.form.get('exam_id')
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files['file']

    if not file or file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    try:
        # Save the image to the temp folder
        unique_filename = f"{uuid.uuid4()}.jpg"
        image_path = os.path.join(UPLOAD_FOLDER, unique_filename)
        image = Image.open(file.stream)
        image.save(image_path, format='JPEG')

        # Analyze the image
        head_orientation = determine_head_orientation(image_path)
        objects = detect_objects(image_path)
        person_count = detect_faces(image_path)

        # Check if any objects are detected
        violation_objects = ['cell phone', 'book', 'laptop', 'paper']
        violating_objects = [object for object in objects if object in violation_objects]

        if violating_objects:
            # Save the image to the violation folder
            violation_filename = f"{datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S-%f')}.jpg"
            violation_image_path = os.path.join(VIOLATION_FOLDER, violation_filename)
            os.rename(image_path, violation_image_path)

            # Save the violation to the database
            student = Student.objects.get(id=student_id)
            exam = Exam.objects.get(id=exam_id)
            violation = Violation(
                student=student,
                exam=exam,
                image_url=violation_filename,
                head_rotation=head_orientation,
                violation_objects=violating_objects,
                person_count=person_count,
            )
            violation.save()

            return jsonify({
                "message": "Image saved to violation folder",
                "filename": violation_filename,
                "head_orientation": head_orientation,
                "person_count": person_count,
                "violating_objects": violating_objects
            }), 201
        else:
            # Delete the image from the temp folder
            os.remove(image_path)
            return jsonify({
                "message": "No violation detected",
                "head_orientation": head_orientation,
                "objects": objects,
                "person_count": person_count
            }), 200
    except Exception as e:
        return jsonify({"error": "Could not process the uploaded file: " + str(e)}), 500